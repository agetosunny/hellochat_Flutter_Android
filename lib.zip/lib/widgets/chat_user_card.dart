import 'package:flutter/material.dart';
import 'package:helloapp/models/chat_user.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:helloapp/screens/chat_screen.dart';

class ChatUserCard extends StatefulWidget {
  final ChatUser user;
  const ChatUserCard({super.key, required this.user});

  @override
  State<ChatUserCard> createState() => _ChatUserCardState();
}

class _ChatUserCardState extends State<ChatUserCard> {
  @override
  Widget build(BuildContext context) {
    final cd = MediaQuery.of(context).size;

    return Card(
      color: const Color.fromARGB(255, 128, 127, 127),
      margin: EdgeInsets.symmetric(horizontal: cd.width * .02, vertical: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: InkWell(
        onTap: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => ChatScreen(
                        user: widget.user,
                      )));
        },
        child: ListTile(
          leading: ClipRRect(
            borderRadius: BorderRadius.circular(cd.height * .48),
            child: CachedNetworkImage(
              height: cd.height * .14,
              width: cd.width * .14,
              imageUrl: widget.user.image,
              progressIndicatorBuilder: (context, url, downloadProgress) =>
                  CircularProgressIndicator(value: downloadProgress.progress),
              errorWidget: (context, url, error) => CircleAvatar(
                child: Icon(Icons.person_rounded),
              ),
            ),
          ),
          title: Text(
            widget.user.name,
            maxLines: 1,
            style: TextStyle(
                color: Colors.black, fontWeight: FontWeight.bold, fontSize: 20),
          ),
          subtitle: Text(
            widget.user.about,
            style: TextStyle(
              color: Colors.black,
            ),
            maxLines: 1,
          ),
          trailing: Container(
            width: 15,
            height: 15,
            decoration: BoxDecoration(
              color: Colors.teal[900],
              borderRadius: BorderRadius.circular(9),
            ),
          ),
        ),
      ),
    );
  }
}

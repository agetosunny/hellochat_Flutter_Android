import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:helloapp/models/chat_user.dart';
import 'package:helloapp/models/message.dart';
import 'package:helloapp/screens/apis.dart';
import 'package:helloapp/widgets/message_card.dart';

class ChatScreen extends StatefulWidget {
  final ChatUser user;
  const ChatScreen({super.key, required this.user});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  List<Message> _list = [];
  final _textController = TextEditingController();

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: []);
  }

  @override
  void dispose() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(statusBarColor: Colors.transparent));
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context).size;
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      onDoubleTap: () => Navigator.pop(context),
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(mq.height * .07),
          child: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: const Color.fromARGB(255, 128, 127, 127),
            flexibleSpace: _appbar(mq),
            elevation: 0,
          ),
        ),
        body: Column(
          children: [
            Expanded(
              child: StreamBuilder(
                stream: APIs.getAllMessages(widget.user),
                builder: (context, snapshot) {
                  switch (snapshot.connectionState) {
                    case ConnectionState.waiting:
                    case ConnectionState.none:
                      return const SizedBox();
                    case ConnectionState.active:
                    case ConnectionState.done:
                      final data = snapshot.data?.docs;
                      _list = data
                              ?.map((e) => Message.fromJson(e.data()))
                              .toList() ??
                          [];
                      print('Firestore data: ${snapshot.data?.docs}');
                      if (_list.isNotEmpty) {
                        return ListView.builder(
                          itemCount: _list.length,
                          padding: EdgeInsets.only(top: mq.height * .03),
                          physics: const BouncingScrollPhysics(),
                          itemBuilder: (context, index) {
                            return MessageCard(message: _list[index]);
                          },
                        );
                      } else {
                        return _buildEmptyMessage(widget.user.name);
                      }
                  }
                },
              ),
            ),
            _chatInput(),
          ],
        ),
      ),
    );
  }

  Widget _appbar(Size mq) {
    return InkWell(
      onTap: () {},
      child: Row(
        children: [
          SizedBox(width: mq.width * 0.09),
          Align(
            alignment: Alignment.bottomLeft,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(mq.height * .05),
              child: CachedNetworkImage(
                imageUrl: widget.user.image,
                width: mq.height * .1,
                height: mq.height * .1,
                errorWidget: (context, url, error) => const CircleAvatar(
                    child: Icon(Icons.person_rounded, color: Colors.black)),
              ),
            ),
          ),
          SizedBox(width: mq.width * 0.02),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.user.name,
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                  fontSize: mq.width * .08,
                ),
              ),
              const Text(
                'last seen at:',
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.w500,
                  fontSize: 15,
                ),
              )
            ],
          ),
        ],
      ),
    );
  }

  Widget _chatInput() {
    return Row(
      children: [
        Expanded(
          child: Card(
            color: const Color.fromARGB(255, 128, 127, 127),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            child: Row(
              children: [
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.emoji_emotions_rounded,
                      color: Colors.black),
                ),
                IconButton(
                  onPressed: () {},
                  icon:
                      const Icon(Icons.camera_alt_rounded, color: Colors.black),
                ),
                IconButton(
                  onPressed: () {},
                  icon:
                      const Icon(Icons.file_copy_rounded, color: Colors.black),
                ),
                Expanded(
                  child: TextField(
                    controller: _textController,
                    keyboardType: TextInputType.multiline,
                    maxLines: null,
                    decoration: const InputDecoration(
                      hintText: 'Enter message...',
                      hintStyle: const TextStyle(color: Colors.black),
                      border: InputBorder.none,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.mic_rounded, color: Colors.black),
                ),
              ],
            ),
          ),
        ),
        MaterialButton(
          onPressed: () {
            if (_textController.text.isNotEmpty) {
              APIs.sendMessage(widget.user, _textController.text);
              _textController.text = '';
            }
          },
          color: const Color.fromARGB(255, 128, 127, 127),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
          padding: const EdgeInsets.all(3.0),
          minWidth: 0,
          height: 0,
          child: Icon(
            Icons.send_rounded,
            color: Colors.black,
            size: 30,
          ),
        )
      ],
    );
  }

  Widget _buildEmptyMessage(String userName) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'No messages here',
            style: TextStyle(
              fontSize: 17,
              color: const Color.fromARGB(255, 128, 127, 127),
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Say Hi to $userName',
            style: const TextStyle(
              fontSize: 17,
              color: Colors.white,
              fontWeight: FontWeight.w500,
            ),
          ),
          const Text(
            '👋🏻',
            style: TextStyle(fontSize: 40),
          )
        ],
      ),
    );
  }
}
